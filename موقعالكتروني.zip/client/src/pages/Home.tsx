import { useState, useEffect } from 'react';
import { Search, Send, Menu, X } from 'lucide-react';
import { Button } from '@/components/ui/button';

/**
 * Hydra Dragon Ghost Shop - Main Page
 * Design: Cyberpunk Elegance with Neon Purple & Cyan
 * Features: Multi-platform search radar, AI assistant, horizontal scrolls
 */

interface SearchResult {
  id: string;
  title: string;
  image: string;
  description: string;
  link: string;
}

export default function Home() {
  const [searchQuery, setSearchQuery] = useState('');
  const [books, setBooks] = useState<SearchResult[]>([]);
  const [videos, setVideos] = useState<SearchResult[]>([]);
  const [apps, setApps] = useState<SearchResult[]>([]);
  const [loading, setLoading] = useState(false);
  const [chatOpen, setChatOpen] = useState(false);
  const [loginOpen, setLoginOpen] = useState(false);
  const [messages, setMessages] = useState<Array<{ role: 'user' | 'bot'; text: string }>>([
    { role: 'bot', text: 'مرحباً بك! أنا هيدرا، محركك الذكي. ابحث عن أي شيء وسأجده لك في كل المنصات.' }
  ]);
  const [chatInput, setChatInput] = useState('');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Handle main search
  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;

    setLoading(true);
    try {
      // Fetch books from Google Books API
      const booksRes = await fetch(
        `https://www.googleapis.com/books/v1/volumes?q=${encodeURIComponent(searchQuery)}&maxResults=8`
      );
      const booksData = await booksRes.json();
      
      if (booksData.items) {
        setBooks(
          booksData.items.map((item: any, idx: number) => ({
            id: `book-${idx}`,
            title: item.volumeInfo.title,
            image: item.volumeInfo.imageLinks?.thumbnail || 'https://via.placeholder.com/150/8b5cf6/ffffff?text=Book',
            description: item.volumeInfo.authors?.[0] || 'مؤلف غير معروف',
            link: item.volumeInfo.previewLink || '#'
          }))
        );
      }
    } catch (err) {
      console.error('Search error:', err);
    }

    // Set up external platform links
    setVideos([
      {
        id: 'youtube',
        title: 'YouTube',
        image: 'https://via.placeholder.com/150/FF0000/ffffff?text=YouTube',
        description: 'ابحث على يوتيوب',
        link: `https://www.youtube.com/results?search_query=${encodeURIComponent(searchQuery)}`
      },
      {
        id: 'tiktok',
        title: 'TikTok',
        image: 'https://via.placeholder.com/150/000000/ffffff?text=TikTok',
        description: 'ابحث على تيك توك',
        link: `https://www.tiktok.com/search?q=${encodeURIComponent(searchQuery)}`
      }
    ]);

    setApps([
      {
        id: 'playstore',
        title: 'Play Store',
        image: 'https://via.placeholder.com/150/3DDC84/ffffff?text=Play',
        description: 'ابحث عن التطبيقات',
        link: `https://play.google.com/store/search?q=${encodeURIComponent(searchQuery)}&c=apps`
      }
    ]);

    setLoading(false);
  };

  // Handle chat message
  const handleChatMessage = () => {
    if (!chatInput.trim()) return;

    // Add user message
    const newMessages = [...messages, { role: 'user' as const, text: chatInput }];
    setMessages(newMessages);

    // Simulate bot response
    setTimeout(() => {
      setMessages([
        ...newMessages,
        {
          role: 'bot',
          text: `لقد قمت بتحديث الرادار للبحث عن "${chatInput}". يمكنك رؤية النتائج في الأقسام أعلاه.`
        }
      ]);
      setSearchQuery(chatInput);
      setChatInput('');
    }, 800);
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <header className="sticky top-0 z-50 glass border-b border-border">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-primary to-secondary flex items-center justify-center">
                <span className="text-xl font-bold">🐉</span>
              </div>
              <h1 className="text-2xl font-bold neon-glow">HYDRA DRAGON</h1>
            </div>

            <div className="hidden md:flex gap-4">
              <Button
                onClick={() => setLoginOpen(true)}
                className="bg-gradient-to-r from-primary to-secondary hover:shadow-lg hover:shadow-primary/50"
              >
                تسجيل دخول
              </Button>
            </div>

            {/* Mobile menu button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden text-primary hover:text-secondary transition"
            >
              {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>

          {/* Search Bar */}
          <form onSubmit={handleSearch} className="relative">
            <div className="relative">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="ابحث عن كتب، تطبيقات، فيديوهات..."
                className="w-full px-4 py-3 pr-12 pl-4 bg-card border border-border rounded-lg focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/50 transition text-foreground placeholder-muted-foreground"
              />
              <button
                type="submit"
                className="absolute left-3 top-1/2 -translate-y-1/2 text-primary hover:text-secondary transition"
              >
                <Search size={20} />
              </button>
            </div>
          </form>
        </div>

        {/* Mobile menu */}
        {mobileMenuOpen && (
          <div className="md:hidden border-t border-border p-4">
            <Button
              onClick={() => {
                setLoginOpen(true);
                setMobileMenuOpen(false);
              }}
              className="w-full bg-gradient-to-r from-primary to-secondary"
            >
              تسجيل دخول
            </Button>
          </div>
        )}
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {loading && (
          <div className="text-center py-12">
            <div className="inline-block">
              <div className="w-12 h-12 border-4 border-primary border-t-secondary rounded-full animate-spin"></div>
            </div>
            <p className="mt-4 text-muted-foreground">جاري البحث في جميع المنصات...</p>
          </div>
        )}

        {/* Books Section */}
        {books.length > 0 && (
          <section className="mb-12">
            <h2 className="text-2xl font-bold mb-6 flex items-center gap-3">
              <span className="text-2xl">📚</span>
              <span className="neon-glow">كتب وروايات</span>
            </h2>
            <div className="horizontal-scroll">
              {books.map((book) => (
                <a
                  key={book.id}
                  href={book.link}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-shrink-0 w-40 group"
                >
                  <div className="glass rounded-lg p-3 hover:glow-box transition-all duration-300 hover:-translate-y-1">
                    <img
                      src={book.image}
                      alt={book.title}
                      className="w-full aspect-square rounded-lg object-cover mb-3 group-hover:shadow-lg group-hover:shadow-primary/50 transition"
                    />
                    <h4 className="font-semibold text-sm line-clamp-2 text-foreground">{book.title}</h4>
                    <p className="text-xs text-muted-foreground mt-1">{book.description}</p>
                  </div>
                </a>
              ))}
            </div>
          </section>
        )}

        {/* Videos Section */}
        {videos.length > 0 && (
          <section className="mb-12">
            <h2 className="text-2xl font-bold mb-6 flex items-center gap-3">
              <span className="text-2xl">🔥</span>
              <span className="neon-glow-cyan">ترندات الفيديو</span>
            </h2>
            <div className="horizontal-scroll">
              {videos.map((video) => (
                <a
                  key={video.id}
                  href={video.link}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-shrink-0 w-40 group"
                >
                  <div className="glass rounded-lg p-3 hover:glow-box-cyan transition-all duration-300 hover:-translate-y-1">
                    <img
                      src={video.image}
                      alt={video.title}
                      className="w-full aspect-square rounded-lg object-cover mb-3 group-hover:shadow-lg group-hover:shadow-secondary/50 transition"
                    />
                    <h4 className="font-semibold text-sm text-foreground">{video.title}</h4>
                    <p className="text-xs text-muted-foreground mt-1">{video.description}</p>
                  </div>
                </a>
              ))}
            </div>
          </section>
        )}

        {/* Apps Section */}
        {apps.length > 0 && (
          <section className="mb-12">
            <h2 className="text-2xl font-bold mb-6 flex items-center gap-3">
              <span className="text-2xl">🎮</span>
              <span className="neon-glow">تطبيقات وألعاب</span>
            </h2>
            <div className="horizontal-scroll">
              {apps.map((app) => (
                <a
                  key={app.id}
                  href={app.link}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-shrink-0 w-40 group"
                >
                  <div className="glass rounded-lg p-3 hover:glow-box transition-all duration-300 hover:-translate-y-1">
                    <img
                      src={app.image}
                      alt={app.title}
                      className="w-full aspect-square rounded-lg object-cover mb-3 group-hover:shadow-lg group-hover:shadow-accent/50 transition"
                    />
                    <h4 className="font-semibold text-sm text-foreground">{app.title}</h4>
                    <p className="text-xs text-muted-foreground mt-1">{app.description}</p>
                  </div>
                </a>
              ))}
            </div>
          </section>
        )}

        {/* Welcome Section */}
        {!searchQuery && books.length === 0 && (
          <div className="text-center py-20">
            <div className="mb-8">
              <div className="w-24 h-24 mx-auto rounded-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center animate-pulse">
                <span className="text-5xl">🐉</span>
              </div>
            </div>
            <h2 className="text-4xl font-bold mb-4 neon-glow">مرحباً بك في هيدرا دراجون</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto mb-8">
              بوابة المستقبل الموحدة للعالم الرقمي. ابحث عن أي شيء وسنجده لك من أقوى المصادر العالمية.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto">
              <div className="glass rounded-lg p-6">
                <div className="text-3xl mb-3">📚</div>
                <h3 className="font-bold mb-2">المكتبة الكبرى</h3>
                <p className="text-sm text-muted-foreground">كتب وروايات من أفضل المصادر العالمية</p>
              </div>
              <div className="glass rounded-lg p-6">
                <div className="text-3xl mb-3">🎮</div>
                <h3 className="font-bold mb-2">المتجر الذكي</h3>
                <p className="text-sm text-muted-foreground">تطبيقات وألعاب من جميع المتاجر</p>
              </div>
              <div className="glass rounded-lg p-6">
                <div className="text-3xl mb-3">🔥</div>
                <h3 className="font-bold mb-2">عالم الفيديو</h3>
                <p className="text-sm text-muted-foreground">ترندات وفيديوهات من أشهر المنصات</p>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* AI Assistant Orb */}
      <button
        onClick={() => setChatOpen(!chatOpen)}
        className="fixed bottom-8 left-8 w-16 h-16 rounded-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center cursor-pointer hover:shadow-2xl hover:shadow-primary/50 transition-all duration-300 z-40 text-2xl"
      >
        🐉
      </button>

      {/* Chat Window */}
      {chatOpen && (
        <div className="fixed bottom-28 left-8 w-96 max-w-[calc(100vw-2rem)] bg-card border border-border rounded-2xl shadow-2xl shadow-primary/20 flex flex-col z-40 overflow-hidden">
          <div className="bg-gradient-to-r from-primary to-secondary p-4 text-white font-bold">
            Hydra AI Assistant
          </div>
          <div className="flex-1 overflow-y-auto p-4 space-y-3 max-h-80">
            {messages.map((msg, idx) => (
              <div
                key={idx}
                className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`max-w-xs px-4 py-2 rounded-lg ${
                    msg.role === 'user'
                      ? 'bg-primary text-white'
                      : 'bg-card border border-border text-foreground'
                  }`}
                >
                  {msg.text}
                </div>
              </div>
            ))}
          </div>
          <div className="border-t border-border p-3 flex gap-2">
            <input
              type="text"
              value={chatInput}
              onChange={(e) => setChatInput(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleChatMessage()}
              placeholder="اسأل هيدرا..."
              className="flex-1 bg-background border border-border rounded-lg px-3 py-2 text-foreground placeholder-muted-foreground focus:outline-none focus:border-primary"
            />
            <button
              onClick={handleChatMessage}
              className="bg-primary hover:bg-secondary text-white p-2 rounded-lg transition"
            >
              <Send size={18} />
            </button>
          </div>
        </div>
      )}

      {/* Login Modal */}
      {loginOpen && (
        <div className="fixed inset-0 bg-black/90 flex items-center justify-center z-50 p-4">
          <div className="bg-card border border-border rounded-2xl p-8 max-w-md w-full">
            <h2 className="text-2xl font-bold mb-2 text-center neon-glow">اربط حساباتك 🔗</h2>
            <p className="text-muted-foreground text-center mb-6">لتحسين تجربة البحث في تيك توك ويوتيوب</p>

            <button className="w-full bg-white text-black font-bold py-3 rounded-lg mb-3 hover:shadow-lg transition flex items-center justify-center gap-2">
              <span>🔵</span> Google
            </button>

            <button className="w-full bg-black text-white font-bold py-3 rounded-lg mb-6 hover:shadow-lg transition flex items-center justify-center gap-2">
              <span>🎵</span> TikTok
            </button>

            <button
              onClick={() => setLoginOpen(false)}
              className="w-full text-muted-foreground hover:text-foreground transition"
            >
              إغلاق
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
